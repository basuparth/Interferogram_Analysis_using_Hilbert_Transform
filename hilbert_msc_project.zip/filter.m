clc
clear all
%  clears your workspace and command window, so you can start fresh
image = double(imread('C:\Users\Dr.Arg\Desktop\Hilbert & fringes\test.png'));
V = rgb2gray(image);
%  returns the double-precision value for loaded image
%V =medfilt2(imagegray);
figure,imshow(V);