%This program is to simulate a continuous phase distribution to act as a dataset 
%for use in the 2D phase unwrapping problem 
clc; close all; clear 
N = 512; 
[x,y]=meshgrid(1:N); 
image1 = 2*peaks(N) + 0.1*x + 0.01*y; 
figure, colormap(gray(256)), imagesc(image1) 
title('Continuous phase image displayed as a visual intensity array') 
xlabel('Pixels'), ylabel('Pixels') 
  
figure  
surf(image1,'FaceColor','interp', 'EdgeColor','none', 'FaceLighting','phong') 
view(-30,30), camlight left, axis tight  
title(' Continuous phase map image displayed as a surface plot') 
xlabel('Pixels'), ylabel('Pixels'), zlabel('Phase in radians') 
  
figure, plot(image1(410,:)) 
title('Row 410 of the continuous phase image') 
xlabel('Pixels'), ylabel('Phase in radians') 
 