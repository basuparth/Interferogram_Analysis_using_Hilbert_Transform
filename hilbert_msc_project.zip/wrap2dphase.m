%wrap the 2D image 
image1_wrapped = atan2(sin(image1), cos(image1)); 
figure, colormap(gray(256)), imagesc(image1_wrapped) 
title('Wrapped phase image displayed as a visual intensity array') 
xlabel('Pixels'), ylabel('Pixels') 
  
figure  
surf(image1_wrapped,'FaceColor','interp', 'EdgeColor','none', 'FaceLighting','phong') 
view(-30,70), camlight left, axis tight  
title('Wrapped phase image plotted as a surface') 
xlabel('Pixels'), ylabel('Pixels'), zlabel('Phase in radians') 
  
figure, plot(image1_wrapped(410,:)) 
title('Row 410 of the wrapped phase image') 
xlabel('Pixels'), ylabel('Phase in radians') 
 