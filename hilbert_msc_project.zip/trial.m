clc
clear all
clc
clear all
clear all
c1=double(imread('C:\Users\Dr.Arg\Desktop\Hilbert & fringes\fr0.png'));
V =medfilt2(c1,[5 5]);
for i=1:1:576
VV=V(i,:);
VV=VV-mean(VV);
HH=hilbert(VV);
IM=imag(HH);
T=atan2(IM,VV);
b(i,:)=T;
NN(i,:)=IM;
DD(i,:)=VV;
end
P=b;
figure,imshow(P,[])
